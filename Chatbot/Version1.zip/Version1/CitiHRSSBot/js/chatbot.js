

//var accessToken ="b2f585554eee486db10cbd40aee2f212";
//var accessToken ="b57f3bc0a50e45e99ef951a8caf59c71"
var accessToken ="772e1d176196414ba9221bcfb8eb8fc1"

var baseUrl = "https://api.dialogflow.com/v1/";

(function () {
    var Message;
    Message = function (arg) {
        this.text = arg.text, this.message_side = arg.message_side;
        this.draw = function (_this) {
            return function () {
                var $message;
                $message = $($('.message_template').clone().html());
                $message.addClass(_this.message_side).find('.text').html(_this.text);
                $('.messages').append($message);
                return $message.addClass('appeared');
               
            };
        }(this);
        return this;
    };
    $(function () {

     
    });
    $(function () {
        var getMessageText, message_side, sendMessage, respText;
        message_side = 'left';


        //Welcome Text when page loads.
        var $messagesInput;
        $messagesInput = $('.messages');
        message_side = message_side ===  'right' ? 'left' : 'right';
        messageInput = new Message({
                                     text: "Hi! Welcome to Citi HR Shared Services. <br> I can help you on your HR queries.",
                                     message_side: message_side
                                  });
                        
        messageInput.draw();
        $messagesInput.animate({ scrollTop: $messagesInput.prop('scrollHeight') }, 300);

        getMessageText = function () {
            var $message_input,$messagesInput, messageInput;
            $message_input = $('.message_input');

            //check for empty text
            if ($message_input.val().trim() === '') {
              return;
            }
            $("#response").scrollTop($("#response").height());
             $messagesInput = $('.messages'); 
             message_side = message_side ===  'right' ? 'left' : 'right';

             messageInput = new Message({
                                     text: $message_input.val(),
                                     message_side: message_side
                                  });
                        
              messageInput.draw();
              $messagesInput.animate({ scrollTop: $messagesInput.prop('scrollHeight') }, 300);

            return $message_input.val();
        };
        sendMessage = function (text) {
                var $messages, message;
                $.ajax({
                      type: "POST",
                      url: baseUrl + "query?v=20150910",
                      contentType: "application/json; charset=utf-8",
                      dataType: "json",
                      headers: {
                          "Authorization": "Bearer " + accessToken
                      },
                      data: JSON.stringify({ query: text, lang: "en", sessionId: "somerandomthing" }),
                      success: function(data) {
                        respText = data.result.fulfillment.speech;                      
                        console.log("Res: " + respText);

                        $("#response").scrollTop($("#response").height());
                              $('.message_input').val('');
                                $messages = $('.messages'); 
                                message_side = message_side === 'left' ? 'right' : 'left';
                              message = new Message({
                                                           text: getPrintableMesage(data.result.fulfillment.speech),
                                                           message_side: message_side
                                        });

                                message.draw();
                                return $messages.animate({ scrollTop: $messages.prop('scrollHeight') }, 300);
                              },
                     error: function() {
                    }
        });

        };
		
		getPrintableMesage = function(text) {
			var jsonObject;
			var customizedText ='';
			try {
				if (text.indexOf('JSON') > -1 ) 
				{ //JSON response
				//1. Prepare the Valid JSON String (TODO : Hencil to remove the below temp code.)
				//text = text.replace("[[", "[{");
				//text = text.replace("]]", "}]");
				//text = text.replace(",[", ",{");
				//text = text.replace("],", "},");
				
				 //text = replaceAll(text, "[[", "[{");
				 text = text.split("[[").join("[{");
				 text = text.split("]]").join("}]");
				 text = text.split(",[").join(",{");
				 text = text.split("],").join("},");
				//text = text.replace(/[[/g, '[{');
				//text = replaceAll(text, "]]", "}]");
				//text = replaceAll(text, ",[", ",{");
				//text = replaceAll(text, "],", "},");
				
				text = "{" + text;
				text = text + "}";
				
				//temp 
				//customizedText = text;
				
				//Construct the final display message
				jsonObject = JSON.parse(text);
				customizedText = jsonObject.TextContent + "<br>"
				
				for (var count=0; count < jsonObject.Buttons.length; count++) {			
					//customizedText = customizedText + '<button style="margin:5px" class="'+jsonObject.Buttons[count].Type+'">'+jsonObject.Buttons[count].Label+'</button>' ;
					
					//customizedText = customizedText + '<button style="margin:5px"  onclick="assignTextBoxValue()" class="'+jsonObject.Buttons[count].Type+'">'+
					//jsonObject.Buttons[count].Label+'</button>' ;
					
					//customizedText = customizedText + '<button id="'+jsonObject.Buttons[count].Name +'"  style="margin:5px"  onclick="assignTextBoxValue()" class="'+jsonObject.Buttons[count].Type+'">'+
					//jsonObject.Buttons[count].Label+'</button>' ;
					
					//Quick Button works 
					//customizedText = customizedText + '<button id="'+jsonObject.Buttons[count].Name +'" Value="Sick Leave"  style="margin:5px"  onclick="optionSelect(this);" class="'+jsonObject.Buttons[count].Type+'">'+
					//jsonObject.Buttons[count].Label+'</button>' ;
					
					//Final Quick buttons code		
					customizedText = customizedText + '<button id="'+jsonObject.Buttons[count].Name +'" Value="'+jsonObject.Buttons[count].Value+'"  style="margin:5px"  onclick="optionSelect(this);" class="'+jsonObject.Buttons[count].Type+'">'+
					jsonObject.Buttons[count].Label+'</button>' ;
					
							
					customizedText = customizedText + '<div class="divider"/>';
					
					//document.getElementById(jsonObject.Buttons[count].Name).addEventListener("click", assignTextBoxValue);
					
				}
				
				//customizedText = "<button class='skyBlueButton' type='button' onclick='optionSelect(this);' id='btnYes' value='Yes'><span>Yes</span> //</button><button class='skyBlueButton' type='button' onclick='optionSelect(this);' id='btnNo' value='No'><span>No</span></button>";
				
				}
				else {
					customizedText = text; 
				}
			}
			catch(err){
			customizedText =text;
			}
			 
		return customizedText;
		}
		
		function replaceAll(str, find, replace) {
			return str.replace(new RegExp(find, 'g'), replace);
		}
		
		optionSelect = function (option) {
			//option button id (btnYes or btnNo)             
			 var value = document.getElementById(option.id);
			//get the value from the button Yes or No
			 var finalValue = value.getAttribute("value");  
			 setInput(finalValue);
			};  
			setInput= function (text) {
			//Yes or No value passed from button is put in the message box
			$('.message_input').val(text);  
			//Yes or No value passed from button is put in the message box
			return sendMessage(getMessageText()); //send message
			}; 


		function assignTextBoxValue(option){
		//window.alert("sometext");
		
		//option button id (btnYes or btnNo)             
		var value = document.getElementById(option.id);
		//get the value from the button Yes or No
		var finalValue = value.getAttribute("value");  
		//setInput(finalValue);

		//Yes or No value passed from button is put in the message box
		$('.message_input').val(finalValue);  
		//Yes or No value passed from button is put in the message box
		return sendMessage(getMessageText()); //send message

 
			//$('.message_input').append("Test");
			//$('.message_input').Val("Test");
		}

        $('.send_message').click(function (e) {
            return sendMessage(getMessageText());
        });
        $('.message_input').keyup(function (e) {
            if (e.which === 13) {
                return sendMessage(getMessageText());
            }
        });
        sendMessage();
        setTimeout(function () {
            return sendMessage();
        }, 1000);
        return setTimeout(function () {
            return sendMessage();
        }, 2000);
    });
    
}.call(this));

