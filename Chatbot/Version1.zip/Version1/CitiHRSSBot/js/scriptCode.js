function assignTextBoxValue(value){
alert(value);
}